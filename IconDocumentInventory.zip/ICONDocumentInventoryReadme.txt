Step1:
Unzip ICONDocumentInventory.zip in the parent directory , The sub directory 
structure should be as follows.

D:.
+---COAC
�   +---CLINCOME
�   +---........
+---Compliance
�   +---FORM13
�   +---........
+---DataMgmt
�   +---ASSETA
�   +---........
+---IT
�   +---CTSBAL
�   +---........
+---Performance
�   +---FRBOND
�   +---........
+---PM
�   +---CITI3
�   +---........
+---Reporting
�   +---BOOKREC
�   +---........
+---Traders
�   +---COMMS
�   +---........
+---TradeSupport
�   +---TTITRD
�   +---........

Step 2.
Create a document (ICONDeptReportList.txt) with following infromation 
Department REPORT_ID ICON_REPORT_ID 
like :
Reporting	TEPLREPT	SR024
Reporting	TESTREP		SR025
Reporting	VLR1T00B	VLR1T00B
Reporting	VLR1T00F	VLR1T00F

Step 3.
Run the batch 
ICONDocumentInventory.bat

Step 4.
CSV File will generate with following name
ICON_DOCUMENT_STATUS.csv

